package Questao1;

public class ClassePrincipal {

    public static void main(String[] args) {
        AtrMtd ObjConta1 = new AtrMtd();
        ObjConta1.Cliente="Maria";
        ObjConta1.Agencia = 2525;
        ObjConta1.Numero = 12975-0;
        ObjConta1.Saldo = 200.0f;
        ObjConta1.depositar = 100.00f;
       
        System.out.println(ObjConta1.retornaDados());
        System.out.println("Saque: " +ObjConta1.Sacar(50.00f));
        
    }
    
}
