package Questao1;

public class AtrMtd {
    String Cliente;
    int Agencia;
    float Numero;
    float Saldo;
    float depositar;
    
    
    
    float Depositar(){
        return Saldo = Saldo + depositar;
    }
     
    float Sacar(float saque){
       return this.Depositar() - saque;
     }
    
     String retornaDados(){
        return "Nome: "+Cliente+ "\nAgencia: " +Agencia+ "\nNumero: " +Numero+ 
                "\nSaldo: " +Saldo+ "\nSalto Total: "+Depositar();
    }
      
    
    
}
