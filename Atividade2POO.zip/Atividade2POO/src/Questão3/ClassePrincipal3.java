package Questão3;

public class ClassePrincipal3 {
    
     public static void main(String[] args) {
        AtrMtd3 ObjAluno1 = new AtrMtd3();
        ObjAluno1.nome="Maria";
        ObjAluno1.nota[0] = 9f;
        ObjAluno1.nota[1] = 7f;
        System.out.println(ObjAluno1.RetornaDados());
        
        AtrMtd3 ObjAluno2 = new AtrMtd3();
        ObjAluno2.nome="Maria";
        ObjAluno2.nota[0] = 9f;
        ObjAluno2.nota[1] = 5f;
        System.out.println(ObjAluno2.RetornaDados());
        
    }
    
}
