package Questão3;

public class AtrMtd3 {
    /*  Implementar uma classe Aluno com os seguintes atributos: nome e notas (Array para 2-NOTAS).
        Nesta classe, você deverá implementar métodos para:
        a) calcular a média aritmética dos alunos;
        c) imprimir a situação do aluno. Apresente a mensagem Reprovado caso este aluno tenha média
        inferior a 6,0 pontos, do contrário, apresentar a mensagem Aprovado.
        Por fim, crie uma classe Principal, crie objetos, faça a chamada de métodos e apresente os dados.
    */
    
    String nome;
    float[] nota = new float[2];
   
    
    float MdArtmc()
    {return (nota[0] + nota[1])/2;}
    
    String Situacao(float MdArtmc){
        if(MdArtmc >= 6)
        {return "Aprovado\n";}
        else
        {return "Reprovado\n";}
    }
    
    String RetornaDados(){
        return "Nome: "+nome+ "\nNota1 " +nota[0]+ "\nNota2: " +nota[1]+ 
               "\nMedia Aritmética: " +MdArtmc()+ "\nSituacao: " +Situacao(MdArtmc());
    }
    
}
