package Questao2;

public class AtrMtd2 {
    String nome;
    int idade;
    float peso;
    float altura;
    
    
    
    String ClasseEleitoral(){
        if(idade < 16)
            {return   "Voce Não pode Votar";}
        else if(idade > 18 && idade  < 65) 
            {return   "Obrigatório Votar";}
         else {return "Facultativo";}
    }

    float CalcIMC(){
        return peso/(altura * altura);
    }

    String SituacaoIMC(float CalcIMC){
        if(CalcIMC < 18.5)
            {return "Voce esta abaixo do peso Ideal";}
        else if(CalcIMC > 18.5 && CalcIMC < 24.9 ) 
            {return "Parabens Voce esta no peso Ideal";}
        else 
            {return "Voce esta Acima do peso Ideal";}
    }
    
    String retornaDados(){
        return "Nome: "+nome+ "\nIdade: " +idade+ "\nPeso: " +peso+ 
        "\nAltura: " +altura+ "\n\nClasse Eleitoral: " +ClasseEleitoral()+ "\nCalculo IMC: "+CalcIMC()+
        "\nSituação IMC: " +SituacaoIMC(CalcIMC());
    }
}
