package Questao2;

public class ClassePrincipal2 {
    public static void main(String[] args) {
        AtrMtd2 ObjPessoa1 = new AtrMtd2();
        ObjPessoa1.nome = "Maira";
        ObjPessoa1.idade = 70;
        ObjPessoa1.altura = 1.70f;
        ObjPessoa1.peso = 16f;
        
        System.out.println(ObjPessoa1.retornaDados());
    }
    
}
