package Questao4;

public class ClassePrincipal4 {
    
     public static void main(String[] args) {
        AtrMtd4 Funcionario = new AtrMtd4();
        Funcionario.nome="Maria";
        Funcionario.cargo = "Enfermeira";
        Funcionario.salario = 937.00f;
        System.out.println(Funcionario.RetornaDados());
        System.out.println("Valor Hora Extra: "+Funcionario.CalcHrEx(5, Funcionario.CalcHr()));
        System.out.println("Valor Total Salario: "+(Funcionario.CalcHrEx(5,Funcionario.CalcHr())+Funcionario.salario)); 
        System.out.println("Situacao emprestimo: "+Funcionario.Emprestimo(282.25f));
         
        AtrMtd4 Funcionario1 = new AtrMtd4();
        Funcionario1.nome="Joao";
        Funcionario1.cargo = "Contador";
        Funcionario1.salario = 3000.00f;
        System.out.println(Funcionario1.RetornaDados());
        System.out.println("Valor Hora Extra: "+Funcionario1.CalcHrEx(0, Funcionario1.CalcHr()));
        System.out.println("Valor Total Salario: "+(Funcionario1.CalcHrEx(10,Funcionario1.CalcHr())+Funcionario1.salario)); 
        System.out.println("Situacao emprestimo: "+Funcionario1.Emprestimo(425.25f));
        
    }
}
