package Questao4;

public class AtrMtd4 {
    
    String nome;
    String cargo;
    float salario;
    

    //Calculo valor da hora trabalhada no mes
    float CalcHr(){ 
        return salario / 44 ;
    }
    
    //Calculo valor da hora extra.
    float CalcHrEx(int HrEx, float CalcHr){
        return (float) ((CalcHr * HrEx) *0.5);
    }
    
    //Metodo Emprestimo
    String Emprestimo(float ParcEmp){
        if((salario *0.3) > ParcEmp)
            {return "Emprestimo Aprovado";}
        else
            {return "Emprestimo negado";}
        
    }
    
    
    //Retorna os dados para a classe principal   
    String RetornaDados(){
        return "\nNome: "+nome+ "\nCargo " +cargo+ "\nSalario: " +salario+ "\nValor da Hora Trabalhada: "+CalcHr();
               
    }



    
   
    
}
